# Penultimate-Adventure
Penultimate Adventure Software Engineering Class
# Code
 GM.java - main menu start game from here, create jar with this as main class run using java -jar nameoffile
 Game.java Main game loop
 Monster.java Fights are called form here
 NPC.Java the NPC interaction is called from here
 Room.java This is where the navigation from rooms comes into play
 saveGame.java This is used for saving the game using a serializable object
 # powerpoints
 1. Penultimate_Adventure_game_Demo_2.pptx This is the powerpoint for demo 2
 2. Powerpoint1.pptx This is powerpoint for Demo 1.
 # reports
   Full Report 2.pdf  This is the Second Report
   Report 1 Full Report.pdf this is the full second report
   Report3_Final_Full_report.pdf This is the final 3rd full report.

   There are no unit or integration tests. 
   To run the program you need java, you will use bluejay program, you then select create jar, and select GM.java as main class then you will go to command prompt and do java -jar nameoffile.jar to run. There are no special inputs.
   
